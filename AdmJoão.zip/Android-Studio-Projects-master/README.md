<!-- LOGO -->
<p align="center">
  <img src="https://2.bp.blogspot.com/-tzm1twY_ENM/XlCRuI0ZkRI/AAAAAAAAOso/BmNOUANXWxwc5vwslNw3WpjrDlgs9PuwQCLcBGAsYHQ/s1600/pasted%2Bimage%2B0.png" alt="Logo" width="170">
  <h2 align="center">Android Studio Projects</h2>
  <p align="center">Repositório dedicado a projetos desenvolvidos no Android Studio.
  
  </p>
</p>

